﻿namespace Asos.CodeTest
{
    public class CustomerResponse
    {
        public bool IsArchived { get; set; }

        public Customer Customer { get; set; }
    }
}