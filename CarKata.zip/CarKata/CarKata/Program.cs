﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarKata
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            int isEngineOn = 0;
            int i;
            do
            {
                Console.WriteLine("*****CHOOSE AMONG THE BELOW ACTION TO PERFORM*****");
                Console.WriteLine("1.Start Car");
                Console.WriteLine("2.Stop Car");
                Console.WriteLine("3.Brake Car");
                Console.WriteLine("4.Accelerate Car");
                Console.WriteLine("5.Refuel");
                i = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                switch (i)
                {
                    case 1:
                        car.StartCar();
                        isEngineOn = 1;
                        car.Dashboard();
                        break;
                    case 2:
                        car.StopCar();
                        isEngineOn = 0;
                        car.Dashboard();
                        break;
                    case 3:
                        car.BrakeCar();
                        car.Dashboard();
                        break;
                    case 4:
                        car.AccelerateCar();
                        car.Dashboard();
                        break;
                    case 5:
                        car.Refuel();
                        car.Dashboard();
                        break;
                    
                }
            } while (isEngineOn==1);
            
        }
    }
}
