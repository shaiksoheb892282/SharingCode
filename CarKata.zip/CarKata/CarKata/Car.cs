﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarKata
{
    public class Car
    {
        static Random random = new Random();
        public FuelTank fuelTank;
        public int speed;
        public float temperature;
        //public int TO ;
        //public int BY ;
        
        public static float TemperatureCalculator(int cs, float temperature)
        {
            
            if (cs >= 1 && cs <= 60)
            {
                return random.Next(25,30);
            }
            else if (cs >= 61 && cs <= 100)
            {
                return random.Next(30,35);
            }
            else if (cs >= 101 && cs <= 140)
            {
                return random.Next(35,40);
            }
            else if (cs >= 141 && cs <= 200)
            {
                return random.Next(40, 45);
            }
            else if (cs >= 201 && cs <= 250)
            {
                return 45f;
            }
            else
            {
                return 25f;
            }
        }
        public void StartCar()
        {
            fuelTank = new FuelTank();
            speed = 0;
            temperature = 25f;
            
        }
        public void StopCar()
        {
            fuelTank.fuelLevel = 20.00d;
            speed = 0;
            temperature = 25f;
        }
        public void BrakeCar()
        {
            fuelTank.FuelConsumption(speed);
            int BY = 10;
            if ((speed-BY)<0)
            {
                speed = 0;
                temperature = 25f;
                Console.WriteLine("Car Has been Stopped");
            }
            else
            {
                speed -= BY;
                temperature = TemperatureCalculator(speed,temperature);
            }

        }
        public void AccelerateCar()
        {
            fuelTank.FuelConsumption(speed);
            int TO = random.Next(5, 20);
            if ((speed + TO) > 250)
            {
                speed = 250;
                temperature =45f;
            }
            else
            {
                speed += TO;
                temperature =TemperatureCalculator(speed, temperature);
            }

        }

        public void Refuel()
        {
            fuelTank.FuelConsumption(speed);
            fuelTank.Refueled();
        }

        public void Dashboard()
        {
            Console.WriteLine("*****CAR DASHBOARD*****");
            fuelTank.DisplayDashboard();
            Console.WriteLine($"Current Speed : {speed} kmph");
            Console.WriteLine($"Current Speed : {temperature} Celsius");

        }
    }
}
