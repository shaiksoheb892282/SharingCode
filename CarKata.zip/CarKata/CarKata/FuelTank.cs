﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarKata
{
    public class FuelTank
    {
        public double fuelLevel { get; set; }//<60lit 0.0003lit/sec consumption
        public double maxTankCapacity = 60;

        public FuelTank()
        {
            fuelLevel = 20.00d;
        }
        public void DisplayDashboard()
        {
            //Console.WriteLine("----------DASHBOARD----------");
            //Console.WriteLine($"FUEL TANK :{this.fuelLevel} Liters");
            if (this.fuelLevel<5)
            {
                Console.WriteLine(" !!!!!!!!!!!!! CURRENTLY IN RESERVE !!!!!!!!!!!!!");
            }
            else
            {
                Console.WriteLine($"Current fuel level : {this.fuelLevel} Liters");
            }
            
            //Console.WriteLine("Car Engine Temperature : 34°C");
        }
        public void FuelConsumption(int currentSpeed)
        {
            int cs = currentSpeed;
            if (cs >= 1 && cs <= 60)
            {
                this.fuelLevel -= 0.0020;
            }
            else if (cs >= 61 && cs <= 100)
            {
                this.fuelLevel -= 0.0014;
            }
            else if (cs >= 101 && cs <= 140)
            {
                this.fuelLevel -= 0.0020;
            }
            else if (cs >= 141 && cs <= 200)
            {
                this.fuelLevel -= 0.0025;
            }
            else if (cs >= 201 && cs <= 250)
            {
                this.fuelLevel -= 0.0030;
            }
            else
            {
                this.fuelLevel -= 0.0003;
            }

        }
        public void Refueled()
        {
            Console.WriteLine("Enter in Liters to be refueled");
            double refuel = Convert.ToDouble(Console.ReadLine());
            if (this.fuelLevel + refuel > this.maxTankCapacity)
            {
                Console.WriteLine("Refuel amount exceds Total capacity, fill in valid amount");
            }
            else
            {
                this.fuelLevel += refuel;
                Console.WriteLine($"tank is filled upto {this.fuelLevel} Ltr.");
            }
        }
    }
}
