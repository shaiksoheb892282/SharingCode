﻿using System;

namespace Asos.CodeTest
{
    public class FailoverEntry
    {
        public DateTime DateTime { get; set; }
    }
}